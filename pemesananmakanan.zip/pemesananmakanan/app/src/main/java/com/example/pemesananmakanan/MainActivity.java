package com.example.pemesananmakanan;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

import static android.R.string.no;
import static android.os.Build.VERSION_CODES.N;

public class MainActivity extends AppCompatActivity {
    int quantity=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void increment(View view){//perintah tombol tambah
        if(quantity==100){
            Toast.makeText(this,"pesanan maximal 50",Toast.LENGTH_SHORT).show();
            return;
        }
        quantity = quantity+1 ;
        display(quantity);
    }
    public void decrement(View view){//perintah tombol tambah
        if (quantity==1){
            Toast.makeText(this,"pesanan minimal 1",Toast.LENGTH_SHORT).show();
            return;
        }
        quantity = quantity -1;
        display(quantity);
    }


    public void Submitorder(View view) {
        EditText nameEditText=(EditText)findViewById(R.id.edt_name);
        String name=nameEditText.getText().toString();
        Log.v("MainActivity","Nama:"+name);

        EditText pesanEditText=(EditText)findViewById(R.id.edt_pesan);
        String pesan=pesanEditText.getText().toString();
        Log.v("MainActivity","Nama:"+pesan);

        CheckBox mesesChekBox= (CheckBox) findViewById(R.id.meses_checkbox);
        boolean hasmeses=mesesChekBox.isChecked();//mengidentifikasi check
        Log.v("MainActivity","has meses:"+hasmeses);

        CheckBox almondChekBox= (CheckBox) findViewById(R.id.almond_checkbox);
        boolean hasalmond=almondChekBox.isChecked();//mengidentifikasi check
        Log.v("MainActivity","has telormeses:"+hasalmond);

        int price=calculateprice(hasmeses,hasalmond);
        String pricemessage=createOrderSummary(price,name,pesan,hasmeses,hasalmond);


        displayMessage(pricemessage);

    }
    private int calculateprice(boolean addmeses,boolean addalmond)
    {
        int harga=2000;

        if(addmeses){
            harga=harga+1000;
        }

        if (addalmond){
            harga=harga+3000;
        }

        return quantity * harga;
    }
    private String createOrderSummary(int price, String name, String pesan, boolean addmeses, boolean addalmond) {//hasil pemesanan
        String pricemessage=" Nama = "+name;
        pricemessage+="\n Pesanan = "+pesan;
        pricemessage+="\n Tambahkan Meses = " +addmeses;
        pricemessage+="\n Tambahkan Almond = " +addalmond;
        pricemessage+="\n Jumlah Pemesanan = " +quantity;
        pricemessage+="\n Total = Rp." +price;
        pricemessage+="\n Terima Kasih!!!";
        return  pricemessage;
    }

    private void displayMessage(String message) {
        TextView priceTextView = (TextView) findViewById(R.id.price_textview);
        priceTextView.setText(message);
    }
    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_textview);
        quantityTextView.setText("" + number);
    }
    private void displayPrice(int number) {
        TextView priceTextView = (TextView) findViewById(R.id.price_textview);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
    }

}